function replaceCss(css) {
  document.getElementById('pagestyle').setAttribute('href', css)
}
